---
title: Exploring Data Center Energy
cover: /assets/images/covers/cover.jpg
members: YIFANG BAO, YI CHEN, YIJIANG NIU, YAQIAO TANG, SHANGSHU LI, NING WANG
description: Short description of the document for the meta tags (limit to 150 characters, longer will be cut by search engines)
---
We are more and more getting used to using free internet services which is easy to use. Everyone knows that Google and Facebook are more valuable than Unicredit and Mercedes. In the real world, you can see a car or bank everywhere, but you will only feel Internet services on a 5-inch digital screen. In fact, the support of all free Internet services is based on massive resources, especially for the servers in the data centers.

However, the situation about data centers which are known to the public often comes from Internet search engines, news media, social media and other media channels. Can public accurately, objectively and comprehensively understand the current status of the rapidly developing data industry?


We try to restore a whole picture of the data center in the virtual world for people in general who have never got to know about it.
