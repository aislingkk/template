# dd-phase2-template



```shell
bundle exec jekyll serve
```



你的文章应该放在这个下面，你修改的应该是

```
/_questions/visualizations/visualization04.html
assets/js/vis04.js
```



如果你想要加入其他的 js 文件可以在 `assets/js` 里面创建，然后参照

`_layouts/default.html`中第48行的写法引入文件。



拉下代码后执行

```
git rm -r --cached .
git add .
git commit -m "update"
```
